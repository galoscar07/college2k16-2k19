public enum EmotionType {
    Joy, Anger, Sadness, Disgust, Fear;
}