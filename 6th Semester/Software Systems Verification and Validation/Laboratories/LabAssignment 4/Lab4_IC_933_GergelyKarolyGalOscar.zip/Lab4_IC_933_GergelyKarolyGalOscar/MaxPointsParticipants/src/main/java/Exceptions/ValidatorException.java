package Exceptions;

public class ValidatorException extends Exception {
    public ValidatorException(String s){
        super(s);
    }
}
